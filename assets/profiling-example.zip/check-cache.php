<?php
/**
 * Module description
 * 
 * @package General
 * @version $Rev$
 * @copyright $Date$
 * @author $Author$
 * @license BSD License. Feel free to use and modify
 */

include('myFunctions.php');

for($i = 0; $i < MAX; $i++) {
	$directoryListing = new directoryFunctions();
	$data = $directoryListing->loadCache('images');
	if (empty($data)) {
		printf('Cache data is empty, trying to save data');
		$data = $directoryListing->getDirectoryFiles('images');
		$directoryListing->saveCache($data, 'images');
	} else {
		printf('Rescued from cache');
	}
	
	printf("<pre>Done testing iteration %d\n</pre>", ($i+1));
}

$directoryListing->printData($data);
