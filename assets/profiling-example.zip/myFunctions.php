<?php
/**
 * Module description
 * 
 * @package General
 * @version $Rev$
 * @copyright $Date$
 * @author $Author$
 * @license BSD License. Feel free to use and modify
 */

define('MAX', 10);

/**
 * Little example class that goes through a directory and optionally saves all image information onto a cache
 * 
 * @author unreal4u
 */
class directoryFunctions {
	/**
	 * Contains the folder where we want to save the cache files
	 * 
	 * @var string
	 */
	const cacheLocation = 'cache/';
	
	/**
	 * The timeout for the cache file
	 * 
	 * @var int
	 */
	const timeout = 3600;
	
	/**
	 * Returns a cache filename based on the identifier and the parameters
	 * 
	 * @param string $identifier The name of the cache
	 * @param array $parameters Optional arguments of the cache
	 * @return string Returns the filename according to given input
	 */
	private function getCacheFilename($identifier, $parameters=array()) {
		return self::cacheLocation.md5(serialize(array('identifier' => $identifier, 'parameters' => $parameters))).'.cache';
	}
	
	/**
	 * Saves the actual data into the cache
	 * 
	 * @param mixed $data The data we want to write
	 * @param string $identifier The name of the cache
	 * @param array $parameters Optional arguments of the cache
	 * @return boolean Returns true in case the cache could be successfully saved, false otherwise
	 */
	public function saveCache($data, $identifier, $parameters=array()) {
		$filename = $this->getCacheFilename($identifier, $parameters);
		
		$success = file_put_contents($filename, serialize($data));
		if ($success !== false) {
			$success = true;
		}
		return $success;
	}
	
	/**
	 * Loads the given cache
	 * 
	 * @param string $identifier The name of the cache
	 * @param array $parameters Optional arguments of the cache
	 * @return mixed Returns the actual data written previously
	 */
	public function loadCache($identifier, $parameters=array()) {
		$return = false;
		
		$filename = $this->getCacheFilename($identifier, $parameters);
		if (is_readable($filename) && (filemtime($filename) + self::timeout > time())) {
			$return = unserialize(file_get_contents($filename));
		}
		
		return $return;
	}
	
	/**
	 * Does the actual job of going through a directory and retrieving all images
	 * 
	 * @param string $directory The directory we're going to read
	 * @return mixed Returns boolean false if problem with directory (or empty), array with all information otherwise
	 */
	public function getDirectoryFiles($directory='.') {
		$return = false;
		
		if (empty($directory)) {
			$directory = '.';
		}
		
		$directory = rtrim($directory, '/').'/';
		
		$dirHandler = opendir($directory);
		while(($item = readdir($dirHandler)) !== false) {
			if (substr($item, 0, 1) != '.') {
				$imageProperties = $this->getImageProperties($directory.$item);
				if (!empty($imageProperties)) {
					$return[] = $imageProperties;
				}
			}
		}
		
		return $return;
	}
	
	/**
	 * Finds out whether the given file is actually a valid image or not
	 * 
	 * @param string $fileLocation The location of the file we want to test
	 * @return mixed Returns boolean false if file location isn't a valid image, array with data otherwise
	 */
	private function getImageProperties($fileLocation) {
		$validImage = getimagesize($fileLocation);
		if (!empty($validImage)) {
			$validImage = array(
				'validImage' => true,
				'fileLocation' => $fileLocation,
				'width' => $validImage[0],
				'height' => $validImage[1],
				'mime' => $validImage['mime'],
			);
		}
		return $validImage;
	}
	
	/**
	 * Quickly prints data with a message
	 * 
	 * @param mixed $data 
	 */
	public function printData($data) {
		printf('The actual data: ');
		var_dump($data);
		return true;
	}
}
