<?php
/**
 * Module description
 * 
 * @package General
 * @version $Rev$
 * @copyright $Date$
 * @author $Author$
 * @license BSD License. Feel free to use and modify
 */


include('myFunctions.php');

for($i = 0; $i < MAX; $i++) {
	$directoryListing = new directoryFunctions();
	$data = $directoryListing->getDirectoryFiles('images');
	printf("<pre>Done testing iteration %d\n</pre>", ($i+1));
}

$directoryListing->printData($data);
